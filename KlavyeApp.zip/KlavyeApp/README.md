# Benim Klavyem (Android)

1. Android Studio ile klasörü aç (File > Open > KlavyeApp), Gradle sync bitsin.
2. Telefonu bağla (USB hata ayıklama açık) ve Run ▶ tıkla.
3. Açılan uygulamada: "Etkinleştir" -> klavyeyi aç, sonra "Klavyeyi seç" -> Benim Klavyem.

Özellikler: Türkçe Q düzeni (ı ğ ü ş i ö ç), Shift (İ/I doğru büyür), sembol sayfası,
basılı tutunca tekrarlayan silme, titreşim, Enter'ın uygulamaya göre davranması.
